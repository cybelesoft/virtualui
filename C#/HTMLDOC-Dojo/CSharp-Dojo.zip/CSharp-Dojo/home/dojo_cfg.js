djConfig = {   
   parseOnLoad: true,
   debugContainerId: "debugId",
   dojoIframeHistoryUrl: '/dojo/resources/iframe_history.html',
   extraLocale: ['en-us', 'de']
};